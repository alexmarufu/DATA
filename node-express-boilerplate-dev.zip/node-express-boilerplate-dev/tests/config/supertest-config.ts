const constructHeader = () => {
	return {
		'ltz-device':
			'TimeZone=Africa/Johannesburg;Lang=en;SID=call-forwarding',
		authorization:
			'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOjYwLCJpYXQiOjE2MTQyNjQwNzh9.e6oaxbhFDzp9T_dL_XxXQgBmkvNARXIsZxpNKeUDUIs',
	};
};

export default constructHeader;
