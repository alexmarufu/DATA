import request from 'supertest';
import server from '../src/app';
import constructHeader from './config/supertest-config';

it('gets the test endpoint', async () => {
	const response = await request(server).get('/').set(constructHeader());

	expect(response.status).toBe(200);
});
