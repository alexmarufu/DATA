export default {
	exposedHeaders: ['Content-Length', 'LTZ-Device'],
	credentials: true,
};
