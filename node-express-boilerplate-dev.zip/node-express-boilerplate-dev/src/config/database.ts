import { Sequelize } from 'sequelize';
import Logger from '../utils/console';

import dbConfig from './db.config';

const { DB_NAME, HOST_NAME, PORT, USER_NAME, PASSWORD, DIALECT } = dbConfig;

const isProd = process.env.NODE_ENV === 'production';

const db = new Sequelize(
	`${DIALECT}://${USER_NAME}:${PASSWORD}@${HOST_NAME}:${PORT}/${DB_NAME}`,
	{
		// eslint-disable-next-line no-console
		logging: !isProd ? console.log : false,
	}
);

export const SQ = db;

db.authenticate()
	.then(() => Logger.info('Connected successfully'))
	.catch((error) => Logger.error(error));

export default db;
