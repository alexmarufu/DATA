import { AxiosRequestConfig } from 'axios';
import { Services } from '../interfaces/services-interface';
import { HTTPResponse } from '../interfaces/external-http.interface';
import Axios from './config';
import discoverURL from './url-discovery';

/**
 * HTTP GET request
 *
 * @param service Name of micro-service to use
 * @param url Endpoint on the specified micro-service
 * @param data Data to send
 * @returns Promise
 */
export const httpGET = async (
	service: Services,
	url: string,
	data?: Record<string, unknown>,
	config?: AxiosRequestConfig
): Promise<HTTPResponse> => {
	const inputData = data || {};

	const sourceURL = url || '';

	const result = await Axios()
		.get(`${discoverURL(service)}${sourceURL}`, {
			...config,
			params: inputData,
		})
		.then((response) => {
			const { data: resultData } = response;

			return resultData;
		})
		.catch((error) => {
			return {
				success: false,
				message: error,
				data: '',
			};
		});

	return result;
};

/**
 * HTTP POST request
 *
 * @param service Name of micro-service to use
 * @param url Endpoint on the specified micro-service
 * @param data Data to send
 * @returns Promise
 */
export const httpPOST = async (
	service: Services,
	url: string,
	data?: Record<string, unknown>,
	config?: AxiosRequestConfig
): Promise<HTTPResponse> => {
	const inputData = data || {};

	const sourceURL = url || '';

	const result = await Axios()
		.post(`${discoverURL(service)}${sourceURL}`, inputData, config)
		.then((response) => {
			const { data: resultData } = response;

			return resultData;
		})
		.catch((error) => {
			return {
				success: false,
				data: '',
				message: error,
			};
		});

	return result;
};

/**
 * HTTP DELETE request
 *
 * @param service Name of micro-service to use
 * @param url Endpoint on the specified micro-service
 * @param data Data to send
 * @returns Promise
 */
export const httpDELETE = async (
	service: Services,
	url: string,
	data?: Record<string, unknown>,
	config?: AxiosRequestConfig
): Promise<HTTPResponse> => {
	const inputData = data || {};

	const sourceURL = url || '';

	const result = await Axios()
		.delete(`${discoverURL(service)}${sourceURL}`, {
			...config,
			data: inputData,
		})
		.then((response) => {
			const { data: resultData } = response;

			return resultData;
		})
		.catch((error) => {
			return {
				success: false,
				data: '',
				message: error,
			};
		});

	return result;
};

/**
 * HTTP UPDATE request
 *
 * @param service Name of micro-service to use
 * @param url Endpoint on the specified micro-service
 * @param data Data to send
 * @returns Promise
 */
export const httpUPDATE = async (
	service: Services,
	url: string,
	data?: Record<string, unknown>,
	config?: AxiosRequestConfig
): Promise<HTTPResponse> => {
	const inputData = data || {};

	const sourceURL = url || '';

	const result = await Axios()
		.put(`${discoverURL(service)}${sourceURL}`, inputData, config)
		.then((response) => {
			const { data: resultData } = response;

			return resultData;
		})
		.catch((error) => {
			return {
				success: false,
				data: '',
				message: error,
			};
		});

	return result;
};
