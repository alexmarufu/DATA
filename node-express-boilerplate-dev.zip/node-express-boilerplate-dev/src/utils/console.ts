import Logger from '@travsim/yootok-logger';

export default Logger;
