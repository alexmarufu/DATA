export type Services = 'MAIN' | 'AUTH' | 'CART' | 'NOTIFICATION' | 'PAYMENT';
