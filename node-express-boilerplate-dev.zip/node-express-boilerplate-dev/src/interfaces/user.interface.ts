export interface UserSession {
	sub: number;
	iat: number;
	exp: number;
	type: string;
}
