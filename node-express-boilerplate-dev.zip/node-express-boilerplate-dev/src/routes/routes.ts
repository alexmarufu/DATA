import { Router, Express } from 'express';

// Controllers
import * as Welcome from '../controllers/welcome.controller';

const router = Router();

const Routes = (app: Express) => {
	// Server status
	app.use('/', router.get('/', Welcome.index));

	// Add more routes
};

export default Routes;
