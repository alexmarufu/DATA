# Node-express boilerplate
Node-express boilerplate to get started fast

This repo comes with all the setup of esLint, Docker, all put in place. It is based on Typescript.

# Important notice

Don't not edit this repo, unless it's necessary or you want to add more feature setup

# Instructions

To start working on a new project clone this repo, copy the whole project files in put them on your project you are working on and make necessary modifications such as on `package.json`, you must change the `name` to be then name of the project you are creating.

```json

{
	"name": "node-express-boilerplate",
	"version": "1.0.0",
	"private": true,
}

```

<p align="center">
  <img src="./assets/yootok-logo.png" alt="Yootok Logo" />
</p>
